#ifndef GOODS_H
#define GOODS_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlRecord>
#include <QDebug>

namespace Ui {
class Goods;
}

class Goods : public QDialog
{
    Q_OBJECT

public:
    explicit Goods(QWidget *parent = nullptr);
    ~Goods();

    bool ok = false;

private slots:
    void on_buttonBox_accepted();


private:
    Ui::Goods *ui;
};

#endif // GOODS_H
