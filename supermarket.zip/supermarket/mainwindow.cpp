#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //login = new Login;
    //login->exec();
    //while(login->YES == false)
        //login->exec();

    //ui->lcdNumber_2->setDigitCount(2);
    QTimer *pTimer = new QTimer(this);
    // 设置定时间隔
    pTimer->setInterval(1000);
    connect(pTimer, SIGNAL(timeout()), this, SLOT(onTimeOut()));

    // 启动定时器
    pTimer->start();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onTimeOut()
{
    QDateTime curDateTime=QDateTime::currentDateTime();
    ui->lcdNumber->display(int(curDateTime.time().hour()));
    ui->lcdNumber_3->display(int(curDateTime.time().second()));
    ui->lcdNumber_2->display(int(curDateTime.time().minute()));
}

//商品管理
void MainWindow::on_action_triggered()
{
    goods = new Goods;
    goods->exec();
}

//商品销售
void MainWindow::on_action_3_triggered()
{
    f = new Form;
    f->show();
}

//商品查询
void MainWindow::on_action_7_triggered()
{
    find = new Find;
    find->show();
}
