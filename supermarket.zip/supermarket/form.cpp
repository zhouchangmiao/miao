#include "form.h"
#include "ui_form.h"
#include <QMessageBox>

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
    setWindowTitle(tr("商品销售"));



    //db.close();
    ui->tableWidget->setRowCount(30);    //设置行数
    ui->tableWidget->setColumnCount(4); //设置列数
}

Form::~Form()
{
    delete ui;
}

void Form::on_pushButton_clicked()
{
    ui->quit_2->setEnabled(true);
    QSqlQuery query;

    query.exec("select * from user");

    num = ui->num->text().toInt();
    percent = ui->percent->text().toInt();

    if(ui->ID->text().toInt()<=100)
        drink += num;
    else if(ui->ID->text().toInt()>=100 && ui->ID->text().toInt()<=300)
        food += num;
    else {
        other += num;
    }
    for(int rows = 0;rows < 30; rows++)
    {

        QString s = ui->ID->text();
        //query.first();
        if(rows == i){
            while(query.next())
            {
                qDebug()<<query.value(3).toString();
                if(query.value(0)==s)
                {
                    for (int ii = 1;ii<4;ii++)
                        ui->tableWidget->setItem(rows,ii,new QTableWidgetItem(query.value(ii).toString()));
                    query.value(2).setValue(QString::number(query.value(2).toInt()-num));
                    money += num*query.value(3).toDouble();
                    ui->totalprice->setText(QString::number(money));
                    ui->realprice->setText(QString::number(money*percent*0.1));
                    record = false;
                    break;
                }

            }
            if(record)
            {
                QMessageBox::information(NULL, "warning", "无此商品");

                return;
            }
            record = true;
            ui->tableWidget->setItem(rows,0,new QTableWidgetItem(s));
            ui->tableWidget->setItem(rows,2,new QTableWidgetItem(QString::number(num)));
            i++;
            return;
        }
    }

}

//找零
void Form::on_quit_2_clicked()
{
    double get = ui->getmoney->text().toDouble();
    get = get - money*percent*0.1;
    ui->quit->setText(QString::number(get));

    gets += ui->realprice->text().toDouble();
    ui->todaymoney->setText(QString::number(gets));

    Reset();

    slice_food->setLabel(tr("food"));
    slice_food->setValue(food);
    slice_food->setLabelVisible(true); // 显示饼状区对应的数据label
    slice_food->setBrush(QColor(228,255,0));

    slice_drink->setLabel("drink");
    slice_drink->setValue(drink);
    slice_drink->setLabelVisible(true);
    slice_drink->setBrush(QColor(218,0,255));

    slice_other->setLabel("other");
    slice_other->setValue(other);
    slice_other->setLabelVisible(true);
    slice_other->setBrush(QColor(0,240,215));


    // 将两个饼状分区加入series

    series->append(slice_food);
    series->append(slice_drink);
    series->append(slice_other);

    chart->removeSeries(series);
    chart->addSeries(series);

    //delete series;


    chart->setAnimationOptions(QChart::AllAnimations); // 设置显示时的动画效果
    //chart->setAnimationOptions(); // 设置显示时的动画效果




    chartview->show();
    chartview->setChart(chart);

    //ui->verticalLayout->insertWidget(0, chartview);
    ui->verticalLayout_2->addWidget(chartview);

    ui->quit_2->setEnabled(false);


}

void Form::Reset()
{
    //ui->tableWidget->clear();
    for (int i= 0;i<30;i++) {
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(""));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(""));
        ui->tableWidget->setItem(i,2,new QTableWidgetItem(""));
        ui->tableWidget->setItem(i,3,new QTableWidgetItem(""));
    }

    i = 0;
    money = 0;
}

