#include "find.h"
#include "ui_find.h"
#include <QMessageBox>
#include <QSqlQuery>
Find::Find(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Find)
{
    ui->setupUi(this);
}

Find::~Find()
{
    delete ui;
}

void Find::on_find_clicked()
{
    QString ID = ui->IDEdit->text();
    QString name = ui->nameEdit->text();

    QSqlQuery query;

    query.exec("select * from user");


    while(query.next())
    {

        if(query.value(0)==ID || query.value(1) == name)
        {
            ui->lineEdit->setText(QString::number(query.value(2).toInt()));//数量
            ui->lineEdit_2->setText(QString::number(query.value(3).toDouble()));//价格
            return;
        }

    }

    QMessageBox::information(NULL, "warning", "无此商品");
}
