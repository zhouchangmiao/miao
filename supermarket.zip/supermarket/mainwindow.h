#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include "login.h"
#include "goods.h"
#include "form.h"
#include "find.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    Login *login;
    Goods *goods;
    Form *f;
    Find *find;

private slots:
    void on_action_triggered();

    void on_action_3_triggered();

    void on_action_7_triggered();

    void onTimeOut();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
