#include "mainwindow.h"
#include "login.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QSqlDatabase db;

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("shop.db");
    db.open();

    Login *login;
    login = new Login;
    login->exec();

    MainWindow w;

    w.show();
    if(login->YES == false)
        w.close();

    return a.exec();
}
