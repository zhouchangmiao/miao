#include <QCoreApplication>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QDateTime>
#include "login.h"
#include "ui_login.h"

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
}

Login::~Login()
{
    delete ui;
}

void Login::on_pushButton_clicked()
{
    QString  qstr0 = ui->username->text();
    QString  qstr1 = ui->password->text();

    QDateTime curDateTime1=QDateTime::currentDateTime();


    if(qstr0.length()==4 && qstr1.toInt()==curDateTime1.time().hour()*100+curDateTime1.time().minute())
    {
        YES = true;
        this->close();
    }
    else if(qstr0 == "admin" && qstr1 == "password")
    {
        YES = true;
        this->close();
    }
    else
        QMessageBox::information(NULL, "warning", "用户名或密码错误");
}
