#ifndef FORM_H
#define FORM_H

#include <QtCharts>
using namespace QtCharts;
#include <QPieSeries>
#include <QWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QDebug>
#include <QComboBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlRecord>

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();
    int i = 0;
    int num;
    int percent = 1;//折扣
    double money = 0;//应收款

    int food = 0,drink = 0,other = 0;

    double gets = 0;

    bool record = true;

    QChartView *chartview = new QChartView(this);
    QPieSlice *slice_drink = new QPieSlice();
    QPieSlice *slice_food = new QPieSlice();
    QPieSlice *slice_other = new QPieSlice();

    QPieSeries *series = new QPieSeries(this);
    QChart *chart = new QChart();

    void Reset();

private slots:
    void on_pushButton_clicked();

    void on_quit_2_clicked();

private:
    Ui::Form *ui;
};

#endif // FORM_H
