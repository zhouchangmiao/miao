#include "goods.h"
#include "ui_goods.h"

Goods::Goods(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Goods)
{
    ui->setupUi(this);

}

Goods::~Goods()
{
    delete ui;
}

//获取商品信息加入到数据库
void Goods::on_buttonBox_accepted()
{
    QString id = ui->id->text();
    QString name = ui->name->text();
    QString num = ui->num->text();
    QString price = ui->sell->text();

    QSqlQuery query;
    query.exec("select * from user");
    while(query.next())
    {
        if(query.value(0)==id){
            query.value(1).setValue(name);
            query.value(2).setValue(num);
            query.value(3).setValue(price);
            ok = true;
            qDebug()<<"d";
            break;
        }
    }
    if(ok==false)
        query.exec(QObject::tr("insert into user values ('"+id.toLatin1()+"','"+name.toUtf8()+"','"+num.toUtf8()+"','"+price.toUtf8()+"')"));

}

